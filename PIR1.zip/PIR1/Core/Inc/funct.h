/*
 * funct.h
 *
 *  Created on: Jan 2, 2021
 *      Author: 99003162
 */

#include <stdint.h>
#include "main.h"

#ifndef INC_FUNCT_H_
#define INC_FUNCT_H_

void systembegin(uint8_t);
uint16_t AnalogRead(ADC_HandleTypeDef);

#endif /* INC_FUNCT_H_ */
